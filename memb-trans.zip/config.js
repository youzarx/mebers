module.exports = {
  bot: {
    owners: ["780906998962061343" , "780906998962061343"],// owners id
    botID: "1234312706060718201",// bot id
    serverinvte: `https://discord.gg/vMqGSHvcwP`, // Server invite url
    clientSECRET: "ssNmzHLvFk4niTHTAcAsgPOkJvGQfllt" , // Client Secret
    callbackURL: "", // Call Back Url
    TOKEN: (process.env.token) // Bot Token
  },
  website: {
    PORT: "3001",//website port
  }
}
